package com.yourserver.zaguns;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class ReloadCommand implements CommandExecutor {

    private final ZAGunBridge plugin;
    private final GunLootTable lootTable;

    public ReloadCommand(ZAGunBridge plugin, GunLootTable lootTable) {
        this.plugin = plugin;
        this.lootTable = lootTable;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length != 1 || !args[0].equalsIgnoreCase("reload")) {
            sender.sendMessage(ChatColor.RED + "Usage: /" + label + " reload");
            return true;
        }

        try {
            plugin.reloadConfig();
            lootTable.load(plugin.getConfig(), plugin.getLogger());
            sender.sendMessage(ChatColor.GREEN + "[ZAGunBridge] Config reloaded - "
                    + lootTable.size() + " guns loaded.");
            plugin.getLogger().info("Config reloaded via /" + label + " reload by "
                    + sender.getName() + " - " + lootTable.size() + " guns loaded.");
        } catch (Exception ex) {
            sender.sendMessage(ChatColor.RED + "[ZAGunBridge] Reload failed - check console for details.");
            plugin.getLogger().log(java.util.logging.Level.SEVERE, "Failed to reload config", ex);
        }
        return true;
    }
}
