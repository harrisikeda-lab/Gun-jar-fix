package com.yourserver.zaguns;

import me.deecaad.weaponmechanics.WeaponMechanicsAPI;
import org.bukkit.Chunk;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.block.TileState;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.loot.LootContext;
import org.bukkit.loot.LootTable;
import org.bukkit.loot.LootTables;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

import vn.duong2012g.zombieapoc.items.ZItem;
import vn.duong2012g.zombieapoc.items.ZItemRegistry;

import java.util.Random;
import java.util.logging.Level;

/**
 * Walks a square of chunks around a center point, a few chunks per tick, and
 * fills every chest/barrel/shulker_box it finds using MapLootConfig - clearing
 * any existing contents first, since this is meant for populating a fresh map
 * rather than preserving anything. Each container is edited on its LIVE block
 * state (not the detached snapshot getTileEntities() returns) so the changes
 * actually persist, and each is wrapped in its own try/catch so one problem
 * container can't abort the rest of the chunk. Each processed container is
 * tagged with a PersistentDataContainer marker so a normal re-run (e.g. after
 * generating new terrain) only touches containers that haven't been done yet.
 * Pass forceReprocess=true to ignore that tag too and re-roll absolutely
 * everything found, tagged or not.
 */
public class MapLootFiller extends BukkitRunnable {

    private final ZAGunBridge plugin;
    private final MapLootConfig lootConfig;
    private final CommandSender initiator;
    private final NamespacedKey filledKey;
    private final Random random = new Random();

    private final World world;
    private final int centerChunkX;
    private final int centerChunkZ;
    private final int chunkRadius;
    private final int chunksPerTick;
    private final boolean loadUnloadedChunks;
    private final boolean forceReprocess;

    private int dx = -1;
    private int dz = 0;
    private int scanned = 0;
    private int filled = 0;
    private int overwritten = 0;
    private int skippedUnloaded = 0;
    private final int totalChunks;
    private Runnable onComplete;

    public MapLootFiller(ZAGunBridge plugin, MapLootConfig lootConfig, CommandSender initiator,
                          World world, int centerX, int centerZ, int blockRadius, boolean forceReprocess) {
        this.plugin = plugin;
        this.lootConfig = lootConfig;
        this.initiator = initiator;
        this.filledKey = new NamespacedKey(plugin, "loot_filled");
        this.world = world;
        this.centerChunkX = centerX >> 4;
        this.centerChunkZ = centerZ >> 4;
        this.chunkRadius = (blockRadius >> 4) + 1;
        this.chunksPerTick = Math.max(1, plugin.getConfig().getInt("fillmap-chunks-per-tick", 4));
        this.forceReprocess = forceReprocess;
        this.loadUnloadedChunks = plugin.getConfig().getBoolean("fillmap-load-chunks", true);
        int side = (2 * chunkRadius) + 1;
        this.totalChunks = side * side;
    }

    @Override
    public void run() {
        int processedThisTick = 0;

        while (processedThisTick < chunksPerTick) {
            if (dz > chunkRadius) {
                // Finished the whole square.
                finish();
                return;
            }

            int cx = centerChunkX + dx;
            int cz = centerChunkZ + dz;
            processChunk(cx, cz);
            scanned++;
            processedThisTick++;

            dx++;
            if (dx > chunkRadius) {
                dx = -chunkRadius;
                dz++;
            }
        }

        if (scanned % 200 < chunksPerTick) {
            report("Progress: " + scanned + "/" + totalChunks + " chunks scanned, "
                    + filled + " container(s) filled so far"
                    + (skippedUnloaded > 0 ? " (" + skippedUnloaded + " unloaded chunks skipped - "
                            + "set fillmap-load-chunks: true to cover those too)" : "") + ".");
        }
    }

    private void processChunk(int cx, int cz) {
        boolean wasLoaded = world.isChunkLoaded(cx, cz);
        boolean addedTicket = false;

        if (!wasLoaded && !loadUnloadedChunks) {
            // Config says don't touch unloaded terrain - skip it.
            skippedUnloaded++;
            return;
        }

        // Get the chunk handle, then FORCE it to full load with a plugin
        // chunk ticket. Plain getChunkAt(true) can leave a freshly-loaded
        // chunk at a low "border" level where getTileEntities() comes back
        // empty - which is why unloaded areas were getting no loot. A plugin
        // ticket loads it (generating if needed) to a ticking level where
        // block entities are reliably present. We remove the ticket right
        // after so it's free to unload again and memory stays bounded even
        // over a huge radius.
        Chunk chunk = world.getChunkAt(cx, cz);
        if (!wasLoaded) {
            chunk.addPluginChunkTicket(plugin);
            addedTicket = true;
        }

        try {
            // getTileEntities(false) = direct references, not snapshot copies.
            for (BlockState state : chunk.getTileEntities(false)) {
                try {
                    processContainer(state);
                } catch (Exception ex) {
                    plugin.getLogger().log(Level.WARNING, "Failed to fill a container at "
                            + state.getLocation() + " - skipping just this one.", ex);
                }
            }
        } finally {
            if (addedTicket) {
                chunk.removePluginChunkTicket(plugin);
                // Ticket removed - let it unload and save the loot we just wrote.
                world.unloadChunk(cx, cz, true);
            }
        }
    }

    private void processContainer(BlockState state) {
        if (!(state instanceof Container) || !(state instanceof TileState)) {
            return;
        }

        Material material = state.getType();
        MapLootConfig.ContainerTable table = lootConfig.tableFor(material);
        if (table == null) {
            return;
        }

        TileState tileState = (TileState) state;
        if (!forceReprocess && tileState.getPersistentDataContainer().has(filledKey, PersistentDataType.BYTE)) {
            return;
        }

        // Operate on the LIVE container, not this snapshot: getTileEntities()
        // hands back detached snapshots whose getInventory() edits don't write
        // back to the world. Re-fetch the real block state so clears/adds and
        // the PDC tag actually persist. (This was the "items never appeared"
        // bug - the snapshot's inventory was a throwaway copy.)
        BlockState liveState = state.getBlock().getState(false);
        if (!(liveState instanceof Container) || !(liveState instanceof TileState)) {
            return;
        }
        Container liveContainer = (Container) liveState;
        TileState liveTileState = (TileState) liveState;
        Inventory inv = liveContainer.getInventory();

        if (!inv.isEmpty()) {
            inv.clear();
            overwritten++;
        }

        fillContainer(inv, table, liveState.getLocation());

        liveTileState.getPersistentDataContainer().set(filledKey, PersistentDataType.BYTE, (byte) 1);
        // update(force=true, applyPhysics=false): force so it writes even
        // though the block type didn't change, no physics so we don't kick
        // off neighbor updates across potentially thousands of containers.
        liveTileState.update(true, false);
        filled++;
    }

    private void fillContainer(Inventory inv, MapLootConfig.ContainerTable table, org.bukkit.Location location) {
        if (table.vanillaLootTable != null && random.nextDouble() * 100.0 <= table.vanillaLootChance) {
            try {
                LootTables lootTables = LootTables.valueOf(table.vanillaLootTable.toUpperCase());
                LootTable vanilla = lootTables.getLootTable();
                LootContext context = new LootContext.Builder(location).build();
                vanilla.fillInventory(inv, random, context);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Unknown vanilla-loot-table '" + table.vanillaLootTable
                        + "' - check it matches an org.bukkit.loot.LootTables enum name exactly.");
            } catch (Exception ex) {
                plugin.getLogger().log(Level.WARNING, "Failed to roll vanilla loot table "
                        + table.vanillaLootTable, ex);
            }
        }

        for (MapLootConfig.Item item : table.roll(random)) {
            int amount = item.amountMin
                    + (item.amountMax > item.amountMin ? random.nextInt(item.amountMax - item.amountMin + 1) : 0);

            ItemStack stack = resolve(item, amount);
            if (stack != null) {
                inv.addItem(stack);
            }
        }
    }

    private ItemStack resolve(MapLootConfig.Item item, int amount) {
        try {
            switch (item.type) {
                case MATERIAL: {
                    return new ItemStack(item.material, amount);
                }
                case CUSTOM: {
                    ZItem zItem = ZItemRegistry.getItemByKey(item.customKey);
                    if (zItem == null) {
                        plugin.getLogger().warning("Unknown ZombieApocalypseSSS custom item key: "
                                + item.customKey + " - check it exists under items.yml's items: section.");
                        return null;
                    }
                    ItemStack stack = zItem.create();
                    if (stack != null) {
                        stack.setAmount(amount);
                    }
                    return stack;
                }
                case GUN: {
                    ItemStack weapon = WeaponMechanicsAPI.generateWeapon(item.weaponTitle);
                    if (weapon == null) {
                        plugin.getLogger().warning("Unknown WeaponMechanics weapon title: " + item.weaponTitle);
                        return null;
                    }
                    weapon.setAmount(amount);
                    return weapon;
                }
                default:
                    return null;
            }
        } catch (Exception ex) {
            plugin.getLogger().log(Level.WARNING, "Failed to build loot item for map fill", ex);
            return null;
        }
    }

    public void setOnComplete(Runnable onComplete) {
        this.onComplete = onComplete;
    }

    private void finish() {
        cancel();
        report("Done - scanned " + scanned + " chunks, filled " + filled + " container(s)"
                + " (" + overwritten + " had existing contents that were replaced)"
                + (skippedUnloaded > 0 ? (", " + skippedUnloaded + " chunks were unloaded and skipped") : "")
                + ".");
        if (onComplete != null) {
            onComplete.run();
        }
    }

    private void report(String message) {
        String full = "[ZAGunBridge] " + message;
        plugin.getLogger().info(message);
        if (initiator != null) {
            initiator.sendMessage(full);
        }
    }
}
