package com.yourserver.zaguns;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Reads the "guns" section of config.yml, e.g.:
 *
 * min-guns: 0
 * max-guns: 2
 * guns:
 *   AK_47:      { chance: 40, amount-min: 1, amount-max: 1 }
 *   M4A1:       { chance: 40, amount-min: 1, amount-max: 1 }
 *   FN_FAL:     { chance: 30, amount-min: 1, amount-max: 1 }
 *   STG44:      { chance: 30, amount-min: 1, amount-max: 1 }
 *   "FR_5.56":  { chance: 30, amount-min: 1, amount-max: 1 }
 *   MG34:       { chance: 15, amount-min: 1, amount-max: 1 }
 *   Uzi:        { chance: 40, amount-min: 1, amount-max: 1 }
 *   AUG:        { chance: 35, amount-min: 1, amount-max: 1 }
 *   50_GS:      { chance: 35, amount-min: 1, amount-max: 1 }
 *   357_Magnum: { chance: 35, amount-min: 1, amount-max: 1 }
 *   R9_0:       { chance: 25, amount-min: 1, amount-max: 1 }
 *   Origin_12:  { chance: 25, amount-min: 1, amount-max: 1 }
 *   Kar98k:     { chance: 15, amount-min: 1, amount-max: 1 }
 *
 * "chance" is a per-roll percentage (0-100), matching the style already used
 * in ZombieApocalypseSSS's events.yml loot table.
 */
public class GunLootTable {

    public static final class Entry {
        final String weaponTitle;
        final double chance;
        final int amountMin;
        final int amountMax;

        Entry(String weaponTitle, double chance, int amountMin, int amountMax) {
            this.weaponTitle = weaponTitle;
            this.chance = chance;
            this.amountMin = amountMin;
            this.amountMax = amountMax;
        }
    }

    private final List<Entry> entries = new ArrayList<>();
    private final int minGuns;
    private final int maxGuns;
    private final Random random = new Random();

    public GunLootTable(FileConfiguration config) {
        this.minGuns = config.getInt("min-guns", 0);
        this.maxGuns = config.getInt("max-guns", 2);

        ConfigurationSection guns = config.getConfigurationSection("guns");
        if (guns == null) {
            return;
        }

        for (String key : guns.getKeys(false)) {
            ConfigurationSection section = guns.getConfigurationSection(key);
            if (section == null) {
                continue;
            }
            double chance = section.getDouble("chance", 25.0);
            int amountMin = section.getInt("amount-min", 1);
            int amountMax = Math.max(amountMin, section.getInt("amount-max", amountMin));
            entries.add(new Entry(key, chance, amountMin, amountMax));
        }
    }

    public int size() {
        return entries.size();
    }

    /**
     * Rolls a random handful of guns for one supply drop, respecting each
     * entry's individual chance and the min/max total guns per drop.
     */
    public List<Entry> rollForDrop() {
        List<Entry> pool = new ArrayList<>(entries);
        java.util.Collections.shuffle(pool, random);

        List<Entry> result = new ArrayList<>();
        int target = minGuns + (maxGuns > minGuns ? random.nextInt(maxGuns - minGuns + 1) : 0);

        for (Entry entry : pool) {
            if (result.size() >= target) {
                break;
            }
            if (random.nextDouble() * 100.0 <= entry.chance) {
                result.add(entry);
            }
        }
        return result;
    }
}
