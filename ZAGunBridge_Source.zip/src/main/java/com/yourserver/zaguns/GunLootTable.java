package com.yourserver.zaguns;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Reads the "guns" section of config.yml, e.g.:
 *
 * min-guns: 0
 * max-guns: 2
 * guns:
 *   ak_47:  { weapon-title: "AK_47",  chance: 40, amount-min: 1, amount-max: 1 }
 *   fr_556: { weapon-title: "FR_5.56", chance: 30, amount-min: 1, amount-max: 1 }
 *
 * "weapon-title" is the exact WeaponMechanics weapon-config filename (case
 * and punctuation sensitive) passed to WeaponMechanicsAPI.generateWeapon().
 * It is REQUIRED and deliberately separate from the map key above it:
 * Bukkit's YamlConfiguration always splits '.' in a key into a nested
 * section when it loads the file - even when the key is quoted in the
 * YAML source - so a key like "FR_5.56" silently becomes "FR_5" -> "56"
 * and getKeys() can never hand back the real "FR_5.56" string. Keeping
 * the actual weapon title in its own value sidesteps that entirely; the
 * map key ("fr_556" above) can be anything convenient, dots or not.
 *
 * "chance" is a per-roll percentage (0-100), matching the style already
 * used in ZombieApocalypseSSS's events.yml loot table.
 */
public class GunLootTable {

    public static final class Entry {
        final String weaponTitle;
        final double chance;
        final int amountMin;
        final int amountMax;

        Entry(String weaponTitle, double chance, int amountMin, int amountMax) {
            this.weaponTitle = weaponTitle;
            this.chance = chance;
            this.amountMin = amountMin;
            this.amountMax = amountMax;
        }
    }

    private final List<Entry> entries = new ArrayList<>();
    private final int minGuns;
    private final int maxGuns;
    private final Random random = new Random();

    public GunLootTable(FileConfiguration config, java.util.logging.Logger logger) {
        this.minGuns = config.getInt("min-guns", 0);
        this.maxGuns = config.getInt("max-guns", 2);

        ConfigurationSection guns = config.getConfigurationSection("guns");
        if (guns == null) {
            return;
        }

        for (String key : guns.getKeys(false)) {
            ConfigurationSection section = guns.getConfigurationSection(key);
            if (section == null) {
                continue;
            }
            String weaponTitle = section.getString("weapon-title");
            if (weaponTitle == null || weaponTitle.isEmpty()) {
                // Backward-compat fallback for entries with no weapon-title field -
                // only safe for keys that don't contain a dot.
                weaponTitle = key;
                if (logger != null) {
                    logger.warning("guns." + key + " has no 'weapon-title' field - falling back to "
                            + "the config key itself. Add weapon-title if the real WeaponMechanics "
                            + "weapon name contains a dot or differs from the key.");
                }
            }
            double chance = section.getDouble("chance", 25.0);
            int amountMin = section.getInt("amount-min", 1);
            int amountMax = Math.max(amountMin, section.getInt("amount-max", amountMin));
            entries.add(new Entry(weaponTitle, chance, amountMin, amountMax));
        }
    }

    public int size() {
        return entries.size();
    }

    /**
     * Rolls a random handful of guns for one supply drop, respecting each
     * entry's individual chance and the min/max total guns per drop.
     */
    public List<Entry> rollForDrop() {
        List<Entry> pool = new ArrayList<>(entries);
        java.util.Collections.shuffle(pool, random);

        List<Entry> result = new ArrayList<>();
        int target = minGuns + (maxGuns > minGuns ? random.nextInt(maxGuns - minGuns + 1) : 0);

        for (Entry entry : pool) {
            if (result.size() >= target) {
                break;
            }
            if (random.nextDouble() * 100.0 <= entry.chance) {
                result.add(entry);
            }
        }
        return result;
    }
}
