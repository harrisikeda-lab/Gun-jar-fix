package com.yourserver.zaguns;

import me.deecaad.weaponmechanics.WeaponMechanicsAPI;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import vn.duong2012g.zombieapoc.api.events.SupplyDropEvent;

import java.util.Random;
import java.util.List;
import java.util.logging.Level;

public class SupplyDropGunListener implements Listener {

    private final ZAGunBridge plugin;
    private final GunLootTable lootTable;
    private final int searchRadius;
    private final Random random = new Random();

    public SupplyDropGunListener(ZAGunBridge plugin, GunLootTable lootTable) {
        this.plugin = plugin;
        this.lootTable = lootTable;
        // Should be >= supply-drop.spawn-radius.max in events.yml (default 200),
        // since SupplyDropEvent.getLocation() is NOT the chest's position - it's
        // the anchor point (e.g. the triggering player) that the chest was
        // randomly offset from by up to that radius.
        this.searchRadius = plugin.getConfig().getInt("chest-search-radius", 220);
    }

    @EventHandler
    public void onSupplyDrop(SupplyDropEvent event) {
        Location center = event.getLocation();

        Chest chest = findNearestChest(center, searchRadius);
        if (chest == null) {
            plugin.getLogger().warning(
                    "SupplyDropEvent fired but no chest was found within " + searchRadius
                            + " blocks of " + center + " - skipping gun loot.");
            return;
        }

        List<GunLootTable.Entry> rolled = lootTable.rollForDrop();
        Inventory inv = chest.getInventory();
        int added = 0;

        for (GunLootTable.Entry entry : rolled) {
            int amount = entry.amountMin
                    + (entry.amountMax > entry.amountMin ? random.nextInt(entry.amountMax - entry.amountMin + 1) : 0);

            try {
                // WeaponMechanicsAPI.generateWeapon(weaponTitle) builds the fully-configured
                // ItemStack (NBT, custom model data, etc.) for that weapon. There is no
                // (title, amount) overload - it always hands back a single item, so the
                // stack size has to be set on the result afterward.
                ItemStack weapon = WeaponMechanicsAPI.generateWeapon(entry.weaponTitle);
                if (weapon == null) {
                    plugin.getLogger().warning("Unknown WeaponMechanics weapon title: " + entry.weaponTitle
                            + " (check the key matches the weapon's config file name exactly, case-sensitive).");
                    continue;
                }
                weapon.setAmount(amount);
                inv.addItem(weapon);
                added++;
            } catch (Exception ex) {
                plugin.getLogger().log(Level.WARNING,
                        "Failed to generate weapon '" + entry.weaponTitle + "' for supply drop", ex);
            }
        }

        plugin.getLogger().info("Added " + added + " gun(s) to the supply drop chest at "
                + chest.getLocation().getBlockX() + "," + chest.getLocation().getBlockY() + ","
                + chest.getLocation().getBlockZ() + " (rolled " + rolled.size() + ").");
    }

    /**
     * Scans loaded chunks within radius of center for chest tile-entities and
     * returns the nearest one. This assumes the drop chest is the only chest
     * that can exist in that area (recommended: use only barrels/shulkers for
     * other loot containers on your map) - otherwise this could grab the
     * wrong chest.
     */
    private Chest findNearestChest(Location center, int radius) {
        World world = center.getWorld();
        if (world == null) {
            return null;
        }

        int chunkRadius = (radius >> 4) + 1;
        int centerChunkX = center.getBlockX() >> 4;
        int centerChunkZ = center.getBlockZ() >> 4;
        double radiusSq = (double) radius * radius;

        Chest closest = null;
        double closestDistSq = Double.MAX_VALUE;

        for (int dx = -chunkRadius; dx <= chunkRadius; dx++) {
            for (int dz = -chunkRadius; dz <= chunkRadius; dz++) {
                int cx = centerChunkX + dx;
                int cz = centerChunkZ + dz;
                if (!world.isChunkLoaded(cx, cz)) {
                    continue;
                }
                Chunk chunk = world.getChunkAt(cx, cz);
                for (BlockState state : chunk.getTileEntities()) {
                    if (!(state instanceof Chest)) {
                        continue;
                    }
                    double distSq = state.getLocation().distanceSquared(center);
                    if (distSq <= radiusSq && distSq < closestDistSq) {
                        closestDistSq = distSq;
                        closest = (Chest) state;
                    }
                }
            }
        }
        return closest;
    }
}
