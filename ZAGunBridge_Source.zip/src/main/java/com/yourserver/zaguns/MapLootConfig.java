package com.yourserver.zaguns;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.logging.Logger;

/**
 * Reads loot.yml's "containers" section - one loot table per container type
 * (chest / barrel / shulker_box), each with its own min/max item count and
 * item pool. Item types:
 *
 *   type: material  -> vanilla Material, e.g. { type: material, material: IRON_INGOT, chance: 40, amount-min: 2, amount-max: 6 }
 *   type: custom    -> ZombieApocalypseSSS ZItemRegistry key, e.g. { type: custom, key: bandage, chance: 40, amount-min: 1, amount-max: 3 }
 *   type: gun       -> WeaponMechanics weapon, e.g. { type: gun, weapon-title: "AK_47", chance: 8, amount-min: 1, amount-max: 1 }
 *
 * Same dot-in-key gotcha as GunLootTable applies here too, which is why gun
 * entries use an explicit weapon-title field rather than relying on the map
 * key (e.g. "FR_5.56" as a key would silently break).
 */
public class MapLootConfig {

    public enum ItemType { MATERIAL, CUSTOM, GUN }

    public static final class Item {
        final ItemType type;
        final Material material;   // MATERIAL only
        final String customKey;    // CUSTOM only
        final String weaponTitle;  // GUN only
        final double chance;
        final int amountMin;
        final int amountMax;

        Item(ItemType type, Material material, String customKey, String weaponTitle,
             double chance, int amountMin, int amountMax) {
            this.type = type;
            this.material = material;
            this.customKey = customKey;
            this.weaponTitle = weaponTitle;
            this.chance = chance;
            this.amountMin = amountMin;
            this.amountMax = amountMax;
        }
    }

    public static final class ContainerTable {
        int minItems;
        int maxItems;
        final List<Item> items = new ArrayList<>();
        String vanillaLootTable;   // name of an org.bukkit.loot.LootTables enum constant, or null
        double vanillaLootChance;  // 0-100

        public List<Item> roll(Random random) {
            List<Item> pool = new ArrayList<>(items);
            Collections.shuffle(pool, random);

            List<Item> result = new ArrayList<>();
            int target = minItems + (maxItems > minItems ? random.nextInt(maxItems - minItems + 1) : 0);

            for (Item item : pool) {
                if (result.size() >= target) {
                    break;
                }
                if (random.nextDouble() * 100.0 <= item.chance) {
                    result.add(item);
                }
            }
            return result;
        }
    }

    private final Map<String, ContainerTable> tables = new HashMap<>();

    public MapLootConfig(FileConfiguration config, Logger logger) {
        load(config, logger);
    }

    public void load(FileConfiguration config, Logger logger) {
        tables.clear();
        ConfigurationSection containers = config.getConfigurationSection("containers");
        if (containers == null) {
            return;
        }

        for (String containerKey : containers.getKeys(false)) {
            ConfigurationSection containerSection = containers.getConfigurationSection(containerKey);
            if (containerSection == null) {
                continue;
            }

            ContainerTable table = new ContainerTable();
            table.minItems = containerSection.getInt("min-items", 0);
            table.maxItems = containerSection.getInt("max-items", 3);
            table.vanillaLootTable = containerSection.getString("vanilla-loot-table");
            table.vanillaLootChance = containerSection.getDouble("vanilla-loot-chance", 0);
            if (table.vanillaLootTable != null && table.vanillaLootTable.equalsIgnoreCase("NONE")) {
                table.vanillaLootTable = null;
            }

            ConfigurationSection items = containerSection.getConfigurationSection("items");
            if (items != null) {
                for (String itemKey : items.getKeys(false)) {
                    ConfigurationSection itemSection = items.getConfigurationSection(itemKey);
                    if (itemSection == null) {
                        continue;
                    }
                    Item parsed = parseItem(containerKey, itemKey, itemSection, logger);
                    if (parsed != null) {
                        table.items.add(parsed);
                    }
                }
            }

            tables.put(containerKey.toLowerCase(), table);
        }
    }

    private Item parseItem(String containerKey, String itemKey, ConfigurationSection section, Logger logger) {
        String typeStr = section.getString("type", "material");
        double chance = section.getDouble("chance", 25.0);
        int amountMin = section.getInt("amount-min", 1);
        int amountMax = Math.max(amountMin, section.getInt("amount-max", amountMin));

        switch (typeStr.toLowerCase()) {
            case "material": {
                String matName = section.getString("material");
                if (matName == null) {
                    logger.warning("containers." + containerKey + ".items." + itemKey
                            + " has type: material but no 'material' field - skipping.");
                    return null;
                }
                Material material = Material.matchMaterial(matName);
                if (material == null) {
                    logger.warning("containers." + containerKey + ".items." + itemKey
                            + " has unknown material '" + matName + "' - skipping.");
                    return null;
                }
                return new Item(ItemType.MATERIAL, material, null, null, chance, amountMin, amountMax);
            }
            case "custom": {
                String key = section.getString("key");
                if (key == null) {
                    logger.warning("containers." + containerKey + ".items." + itemKey
                            + " has type: custom but no 'key' field - skipping.");
                    return null;
                }
                return new Item(ItemType.CUSTOM, null, key, null, chance, amountMin, amountMax);
            }
            case "gun": {
                String weaponTitle = section.getString("weapon-title");
                if (weaponTitle == null) {
                    logger.warning("containers." + containerKey + ".items." + itemKey
                            + " has type: gun but no 'weapon-title' field - skipping.");
                    return null;
                }
                return new Item(ItemType.GUN, null, null, weaponTitle, chance, amountMin, amountMax);
            }
            default:
                logger.warning("containers." + containerKey + ".items." + itemKey
                        + " has unknown type '" + typeStr + "' (expected material/custom/gun) - skipping.");
                return null;
        }
    }

    /**
     * Maps a physical container Material (CHEST, TRAPPED_CHEST, BARREL, any
     * colored *_SHULKER_BOX) to the loot.yml table that should fill it.
     * Looks for a table named after the specific container type first
     * ("chest"/"barrel"/"shulker_box"), then falls back to a shared "common"
     * table if that specific one isn't defined - which is what the default
     * loot.yml uses, so all container types get identical loot out of the
     * box with zero extra config. Returns null only if neither exists.
     */
    public ContainerTable tableFor(Material material) {
        String key;
        switch (material) {
            case CHEST:
            case TRAPPED_CHEST:
                key = "chest";
                break;
            case BARREL:
                key = "barrel";
                break;
            default:
                if (material.name().endsWith("SHULKER_BOX")) {
                    key = "shulker_box";
                } else {
                    return null;
                }
        }
        ContainerTable specific = tables.get(key);
        return specific != null ? specific : tables.get("common");
    }

    public int tableCount() {
        return tables.size();
    }

    public int totalItemDefinitions() {
        int total = 0;
        for (ContainerTable t : tables.values()) {
            total += t.items.size();
        }
        return total;
    }
}
