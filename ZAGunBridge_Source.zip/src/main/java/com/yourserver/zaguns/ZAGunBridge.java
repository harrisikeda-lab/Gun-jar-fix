package com.yourserver.zaguns;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public final class ZAGunBridge extends JavaPlugin {

    private GunLootTable gunLootTable;
    private MapLootConfig mapLootConfig;
    private File lootConfigFile;
    private FileConfiguration lootConfig;

    @Override
    public void onEnable() {
        saveDefaultConfig(); // copies config.yml (guns + supply-drop settings) out of the jar on first run only
        overwriteLootConfig(); // ALWAYS replaces loot.yml with the bundled default on every start

        this.gunLootTable = new GunLootTable(getConfig(), getLogger());
        this.mapLootConfig = new MapLootConfig(getLootConfigFile(), getLogger());

        getServer().getPluginManager().registerEvents(
                new SupplyDropGunListener(this, gunLootTable), this);
        getCommand("zagunbridge").setExecutor(new ZAGunBridgeCommand(this, gunLootTable, mapLootConfig));

        getLogger().info("ZAGunBridge enabled - " + gunLootTable.size() + " guns, "
                + mapLootConfig.tableCount() + " container table(s) ("
                + mapLootConfig.totalItemDefinitions() + " item entries) loaded.");
    }

    /**
     * loot.yml is a second config file (map-fill loot tables), kept separate
     * from config.yml (supply-drop gun settings) since they're conceptually
     * different systems and either one growing large shouldn't clutter the
     * other. Loaded/reloaded the same way Bukkit handles the main config.
     */
    public FileConfiguration getLootConfigFile() {
        if (lootConfig == null) {
            reloadLootConfig();
        }
        return lootConfig;
    }

    public void reloadLootConfig() {
        if (lootConfigFile == null) {
            lootConfigFile = new File(getDataFolder(), "loot.yml");
        }
        lootConfig = YamlConfiguration.loadConfiguration(lootConfigFile);

        // Layer in any new defaults added in a plugin update, same idea as
        // JavaPlugin's own getConfig() default-merging behavior.
        InputStream defaultStream = getResource("loot.yml");
        if (defaultStream != null) {
            YamlConfiguration defaultConfig = YamlConfiguration.loadConfiguration(
                    new InputStreamReader(defaultStream, StandardCharsets.UTF_8));
            lootConfig.setDefaults(defaultConfig);
        }
    }

    /**
     * Unlike saveDefaultConfig()/the old saveLootConfigIfMissing(), this
     * REPLACES plugins/ZAGunBridge/loot.yml with the jar's bundled default
     * every single time the plugin enables - any manual edits to it will be
     * lost on every server restart or /reload. This was requested explicitly
     * to force stale/broken entries out of a live server's copy; if you want
     * to go back to normal "keep my edits" behavior (like config.yml has),
     * change this back to only save when the file is missing.
     */
    private void overwriteLootConfig() {
        try {
            saveResource("loot.yml", true);
        } catch (IllegalArgumentException ex) {
            getLogger().warning("No bundled loot.yml resource found to copy - "
                    + "map filling will have no item tables until one is created manually.");
        }
    }
}
