package com.yourserver.zaguns;

import org.bukkit.plugin.java.JavaPlugin;

public final class ZAGunBridge extends JavaPlugin {

    private GunLootTable lootTable;

    @Override
    public void onEnable() {
        saveDefaultConfig(); // copies guns.yml-equivalent config out of the jar on first run
        this.lootTable = new GunLootTable(getConfig(), getLogger());
        getServer().getPluginManager().registerEvents(
                new SupplyDropGunListener(this, lootTable), this);
        getCommand("zagunbridge").setExecutor(new ReloadCommand(this, lootTable));
        getLogger().info("ZAGunBridge enabled - " + lootTable.size() + " guns loaded.");
    }
}
