package com.yourserver.zaguns;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public final class ZAGunBridge extends JavaPlugin {

    private GunLootTable gunLootTable;
    private MapLootConfig mapLootConfig;
    private File lootConfigFile;
    private FileConfiguration lootConfig;

    @Override
    public void onEnable() {
        saveDefaultConfig(); // copies config.yml (guns + supply-drop settings) out of the jar on first run
        saveLootConfigIfMissing(); // copies loot.yml (map fill tables) out of the jar on first run

        this.gunLootTable = new GunLootTable(getConfig(), getLogger());
        this.mapLootConfig = new MapLootConfig(getLootConfigFile(), getLogger());

        getServer().getPluginManager().registerEvents(
                new SupplyDropGunListener(this, gunLootTable), this);
        getCommand("zagunbridge").setExecutor(new ZAGunBridgeCommand(this, gunLootTable, mapLootConfig));

        getLogger().info("ZAGunBridge enabled - " + gunLootTable.size() + " guns, "
                + mapLootConfig.tableCount() + " container table(s) ("
                + mapLootConfig.totalItemDefinitions() + " item entries) loaded.");
    }

    /**
     * loot.yml is a second config file (map-fill loot tables), kept separate
     * from config.yml (supply-drop gun settings) since they're conceptually
     * different systems and either one growing large shouldn't clutter the
     * other. Loaded/reloaded the same way Bukkit handles the main config.
     */
    public FileConfiguration getLootConfigFile() {
        if (lootConfig == null) {
            reloadLootConfig();
        }
        return lootConfig;
    }

    public void reloadLootConfig() {
        if (lootConfigFile == null) {
            lootConfigFile = new File(getDataFolder(), "loot.yml");
        }
        lootConfig = YamlConfiguration.loadConfiguration(lootConfigFile);

        // Layer in any new defaults added in a plugin update, same idea as
        // JavaPlugin's own getConfig() default-merging behavior.
        InputStream defaultStream = getResource("loot.yml");
        if (defaultStream != null) {
            YamlConfiguration defaultConfig = YamlConfiguration.loadConfiguration(
                    new InputStreamReader(defaultStream, StandardCharsets.UTF_8));
            lootConfig.setDefaults(defaultConfig);
        }
    }

    private void saveLootConfigIfMissing() {
        File file = new File(getDataFolder(), "loot.yml");
        if (!file.exists()) {
            try {
                saveResource("loot.yml", false);
            } catch (IllegalArgumentException ex) {
                getLogger().warning("No bundled loot.yml resource found to copy - "
                        + "map filling will have no item tables until one is created manually.");
            }
        }
    }
}
