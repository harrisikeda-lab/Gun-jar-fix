package com.yourserver.zaguns;

import org.bukkit.plugin.java.JavaPlugin;

public final class ZAGunBridge extends JavaPlugin {

    private GunLootTable lootTable;

    @Override
    public void onEnable() {
        saveDefaultConfig(); // copies guns.yml-equivalent config out of the jar on first run
        this.lootTable = new GunLootTable(getConfig());
        getServer().getPluginManager().registerEvents(
                new SupplyDropGunListener(this, lootTable), this);
        getLogger().info("ZAGunBridge enabled - " + lootTable.size() + " guns loaded.");
    }
}
