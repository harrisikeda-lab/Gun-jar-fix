package com.yourserver.zaguns;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ZAGunBridgeCommand implements CommandExecutor {

    private final ZAGunBridge plugin;
    private final GunLootTable gunLootTable;
    private final MapLootConfig mapLootConfig;

    private MapLootFiller activeFiller;

    public ZAGunBridgeCommand(ZAGunBridge plugin, GunLootTable gunLootTable, MapLootConfig mapLootConfig) {
        this.plugin = plugin;
        this.gunLootTable = gunLootTable;
        this.mapLootConfig = mapLootConfig;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendUsage(sender, label);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload":
                return handleReload(sender, label);
            case "fillmap":
                return handleFillMap(sender, label, args);
            default:
                sendUsage(sender, label);
                return true;
        }
    }

    private void sendUsage(CommandSender sender, String label) {
        sender.sendMessage(ChatColor.RED + "Usage:");
        sender.sendMessage(ChatColor.RED + "  /" + label + " reload");
        sender.sendMessage(ChatColor.RED + "  /" + label + " fillmap [radius]");
        sender.sendMessage(ChatColor.RED + "  /" + label + " fillmap stop");
    }

    private boolean handleReload(CommandSender sender, String label) {
        try {
            plugin.reloadConfig();
            gunLootTable.load(plugin.getConfig(), plugin.getLogger());
            plugin.reloadLootConfig();
            mapLootConfig.load(plugin.getLootConfigFile(), plugin.getLogger());
            sender.sendMessage(ChatColor.GREEN + "[ZAGunBridge] Config reloaded - "
                    + gunLootTable.size() + " guns, " + mapLootConfig.tableCount()
                    + " container table(s) (" + mapLootConfig.totalItemDefinitions() + " item entries) loaded.");
            plugin.getLogger().info("Config reloaded via /" + label + " reload by " + sender.getName() + ".");
        } catch (Exception ex) {
            sender.sendMessage(ChatColor.RED + "[ZAGunBridge] Reload failed - check console for details.");
            plugin.getLogger().log(java.util.logging.Level.SEVERE, "Failed to reload config", ex);
        }
        return true;
    }

    private boolean handleFillMap(CommandSender sender, String label, String[] args) {
        if (args.length >= 2 && args[1].equalsIgnoreCase("stop")) {
            if (activeFiller != null) {
                activeFiller.cancel();
                activeFiller = null;
                sender.sendMessage(ChatColor.YELLOW + "[ZAGunBridge] Map fill stopped.");
            } else {
                sender.sendMessage(ChatColor.YELLOW + "[ZAGunBridge] No map fill is currently running.");
            }
            return true;
        }

        if (activeFiller != null) {
            sender.sendMessage(ChatColor.RED + "[ZAGunBridge] A map fill is already running - use '/"
                    + label + " fillmap stop' first.");
            return true;
        }

        Location center;
        if (sender instanceof Player) {
            center = ((Player) sender).getLocation();
        } else {
            World world = plugin.getServer().getWorlds().get(0);
            center = world.getSpawnLocation();
            sender.sendMessage(ChatColor.YELLOW + "[ZAGunBridge] Console has no location - centering on "
                    + world.getName() + "'s spawn point instead.");
        }

        int radius = plugin.getConfig().getInt("fillmap-default-radius", 300);
        if (args.length >= 2) {
            try {
                radius = Integer.parseInt(args[1]);
            } catch (NumberFormatException ex) {
                sender.sendMessage(ChatColor.RED + "[ZAGunBridge] '" + args[1]
                        + "' isn't a number or 'stop'. Usage: /" + label + " fillmap [radius|stop]");
                return true;
            }
        }

        if (mapLootConfig.tableCount() == 0) {
            sender.sendMessage(ChatColor.RED + "[ZAGunBridge] loot.yml has no 'containers' configured - "
                    + "nothing to fill. Check plugins/ZAGunBridge/loot.yml.");
            return true;
        }

        sender.sendMessage(ChatColor.GREEN + "[ZAGunBridge] Starting map fill: radius " + radius
                + " blocks around " + center.getBlockX() + "," + center.getBlockZ()
                + " in " + center.getWorld().getName() + ". Use '/" + label + " fillmap stop' to cancel.");

        activeFiller = new MapLootFiller(plugin, mapLootConfig, sender, center.getWorld(),
                center.getBlockX(), center.getBlockZ(), radius);
        activeFiller.setOnComplete(() -> activeFiller = null);
        long period = 1L; // run every tick, throttled internally by fillmap-chunks-per-tick
        activeFiller.runTaskTimer(plugin, 0L, period);
        return true;
    }
}
