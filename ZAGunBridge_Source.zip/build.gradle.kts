plugins {
    id("java")
}

group = "com.yourserver"
version = "1.0.0"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    // Real Paper API, pulled from PaperMC's repo at build time on GitHub Actions.
    // NOTE: this version string may not match your actual server build - check
    // https://repo.papermc.io/#browse/browse:maven-public:io%2Fpapermc%2Fpaper%2Fpaper-api
    // (or run "version" in your server console) and update if needed.
    compileOnly("io.papermc.paper:paper-api:1.20.4-R0.1-SNAPSHOT")

    // WeaponMechanics and ZombieApocalypseSSS aren't published on any public
    // repo, so they're bundled straight in this project's libs/ folder
    // (the exact jars you uploaded) and referenced as local files instead.
    compileOnly(files("libs/WeaponMechanics-4_3_1.jar"))
    compileOnly(files("libs/ZombieApocalypseSSS-4_7_0.jar"))
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(21))
    }
}

tasks.withType<Jar> {
    archiveBaseName.set("ZAGunBridge")
}

tasks.processResources {
    duplicatesStrategy = DuplicatesStrategy.INCLUDE
}
