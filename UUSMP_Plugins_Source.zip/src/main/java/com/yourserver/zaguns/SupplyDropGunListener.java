package com.yourserver.zaguns;

import me.deecaad.weaponmechanics.WeaponMechanicsAPI;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import vn.duong2012g.zombieapoc.api.events.SupplyDropEvent;

import java.util.List;
import java.util.Random;
import java.util.logging.Level;

public class SupplyDropGunListener implements Listener {

    private final ZAGunBridge plugin;
    private final GunLootTable lootTable;
    private final Random random = new Random();

    public SupplyDropGunListener(ZAGunBridge plugin, GunLootTable lootTable) {
        this.plugin = plugin;
        this.lootTable = lootTable;
    }

    @EventHandler
    public void onSupplyDrop(SupplyDropEvent event) {
        Location loc = event.getLocation();

        Chest chest = findNearbyChest(loc);
        if (chest == null) {
            plugin.getLogger().warning(
                    "SupplyDropEvent fired but no chest was found near " + loc + " - skipping gun loot.");
            return;
        }

        List<GunLootTable.Entry> rolled = lootTable.rollForDrop();
        Inventory inv = chest.getInventory();

        for (GunLootTable.Entry entry : rolled) {
            int amount = entry.amountMin
                    + (entry.amountMax > entry.amountMin ? random.nextInt(entry.amountMax - entry.amountMin + 1) : 0);

            try {
                // WeaponMechanicsAPI.generateWeapon(weaponTitle) builds the fully-configured
                // ItemStack (NBT, custom model data, etc.) for that weapon. There is no
                // (title, amount) overload - it always hands back a single item, so the
                // stack size has to be set on the result afterward.
                ItemStack weapon = WeaponMechanicsAPI.generateWeapon(entry.weaponTitle);
                if (weapon == null) {
                    plugin.getLogger().warning("Unknown WeaponMechanics weapon title: " + entry.weaponTitle
                            + " (check the key matches the weapon's config file name exactly, case-sensitive).");
                    continue;
                }
                weapon.setAmount(amount);
                inv.addItem(weapon);
            } catch (Exception ex) {
                plugin.getLogger().log(Level.WARNING,
                        "Failed to generate weapon '" + entry.weaponTitle + "' for supply drop", ex);
            }
        }
    }

    /**
     * ZombieApocalypseSSS's SupplyDropEvent only exposes getLocation() with no
     * direct block/chest reference, so we search a small radius around it for
     * the chest it just placed. Adjust the radius if your drops use a
     * different structure (e.g. a barrel, or the chest one block above spawn).
     */
    private Chest findNearbyChest(Location center) {
        int radius = 2;
        Block centerBlock = center.getBlock();

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -1; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    Block block = centerBlock.getRelative(dx, dy, dz);
                    if (block.getType() == Material.CHEST) {
                        BlockState state = block.getState();
                        if (state instanceof Chest) {
                            return (Chest) state;
                        }
                    }
                }
            }
        }
        return null;
    }
}
